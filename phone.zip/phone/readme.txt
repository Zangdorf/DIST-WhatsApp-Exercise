1) .zip files are the original files of the exercise

2) in order to connect in the application, please check the database, or create your own users
